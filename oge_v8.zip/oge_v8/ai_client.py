"""
Обёртка над OpenRouter API.

OpenRouter — единая точка доступа ко множеству LLM. Использует
OpenAI-совместимый API. Регистрируешься, кладёшь $5 на счёт,
получаешь ключ, и можешь вызывать любую модель.

Документация: https://openrouter.ai/docs

Используется для:
1. Проверки сочинений и изложений по русскому
2. Разбора фотографий с задачами по физике/математике
3. Автопроверки развёрнутых ответов
"""

from __future__ import annotations
import json
import logging
import urllib.request
import urllib.error
from typing import Optional

from config import (
    OPENROUTER_API_KEY,
    OPENROUTER_TEXT_MODEL,
    OPENROUTER_VISION_MODEL,
    AI_CHECK_ENABLED,
)

log = logging.getLogger(__name__)

API_URL = "https://openrouter.ai/api/v1/chat/completions"
TIMEOUT = 60  # секунд


class AINotConfigured(Exception):
    """OpenRouter API ключ не задан."""


def is_configured() -> bool:
    return AI_CHECK_ENABLED


def _post(payload: dict) -> dict:
    """Низкоуровневый POST к OpenRouter."""
    if not OPENROUTER_API_KEY:
        raise AINotConfigured("OPENROUTER_API_KEY не задан в config.py")

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        API_URL,
        data=data,
        headers={
            "Authorization": f"Bearer {OPENROUTER_API_KEY}",
            "Content-Type": "application/json",
            # рекомендованные заголовки от OpenRouter
            "HTTP-Referer": "https://t.me/oge_bot",
            "X-Title": "OGE Telegram Bot",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            body = resp.read().decode("utf-8")
            return json.loads(body)
    except urllib.error.HTTPError as e:
        err_body = e.read().decode("utf-8", errors="replace")
        log.error("OpenRouter HTTPError %s: %s", e.code, err_body)
        raise RuntimeError(f"OpenRouter вернул {e.code}: {err_body[:300]}")
    except urllib.error.URLError as e:
        log.error("OpenRouter URLError: %s", e)
        raise RuntimeError(f"Не удалось дозвониться до OpenRouter: {e}")


def ask_text(system_prompt: str, user_prompt: str, *, model: Optional[str] = None,
             max_tokens: int = 2000, temperature: float = 0.3) -> str:
    """Простой текстовый запрос. Возвращает строку-ответ модели."""
    payload = {
        "model": model or OPENROUTER_TEXT_MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    resp = _post(payload)
    return resp["choices"][0]["message"]["content"]


def ask_with_image(system_prompt: str, user_prompt: str, image_url: str,
                   *, model: Optional[str] = None, max_tokens: int = 2000) -> str:
    """Запрос с картинкой. image_url — публичный URL картинки
    (для Telegram-фото подойдёт прямая ссылка от bot.get_file()).
    """
    payload = {
        "model": model or OPENROUTER_VISION_MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": user_prompt},
                    {"type": "image_url", "image_url": {"url": image_url}},
                ],
            },
        ],
        "max_tokens": max_tokens,
    }
    resp = _post(payload)
    return resp["choices"][0]["message"]["content"]


def ask_with_image_b64(system_prompt: str, user_prompt: str, image_b64: str,
                       mime: str = "image/jpeg",
                       *, model: Optional[str] = None, max_tokens: int = 2000) -> str:
    """То же, но картинка передаётся в base64 (data:URL).
    Удобнее для Telegram — не нужно хостить файл.
    """
    data_url = f"data:{mime};base64,{image_b64}"
    return ask_with_image(system_prompt, user_prompt, data_url,
                          model=model, max_tokens=max_tokens)
