"""
ОГЭ Подготовка — Telegram Bot v8

Новое в v8:
• задания подгружаются из JSON-файлов в data/<subject>/tasks/*.json
• поддержка фото-ответов (для развёрнутых заданий — через AI)
• проверка изложений и сочинений по критериям ОГЭ (через OpenRouter)
• единый файл определений на каждый предмет

Запуск:
    pip install -r requirements.txt
    # отредактируй config.py — токен и (опционально) ключ OpenRouter
    python bot.py
"""

import base64
import logging
from io import BytesIO

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ConversationHandler,
    filters,
    ContextTypes,
)

from config import BOT_TOKEN, DATA_DIR
from subjects import physics, math_oge, russian, informatics
import task_loader
import ai_checker
import ai_client

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# ─── Состояния диалога ───────────────────────────────────────────
(
    CHOOSE_SUBJECT,
    CHOOSE_ACTION,
    CHOOSE_TASK_NUM,
    WAITING_ANSWER,
    READING_CONSPECT,
    SEARCH_DEFINITION,
    WAITING_IZLOZHENIE,
    WAITING_SOCHINENIE,
) = range(8)

# ─── Реестр предметов ────────────────────────────────────────────
SUBJECTS = {
    "physics": {"name": "🔬 Физика",          "module": physics,     "key": "physics"},
    "math":    {"name": "📐 Математика",      "module": math_oge,    "key": "math"},
    "russian": {"name": "📖 Русский язык",    "module": russian,     "key": "russian"},
    "informatics": {"name": "💻 Информатика", "module": informatics, "key": "informatics"},
}

# ─── Загрузка JSON-заданий при старте ────────────────────────────
EXTERNAL_TASKS: dict[str, dict[int, list[dict]]] = {}


def load_external_tasks():
    """Подгружает задания из data/<subject>/tasks/*.json."""
    for key in SUBJECTS:
        EXTERNAL_TASKS[key] = task_loader.load_tasks(DATA_DIR, key)
        if EXTERNAL_TASKS[key]:
            total = sum(len(v) for v in EXTERNAL_TASKS[key].values())
            logger.info("Загружено %d JSON-заданий для %s", total, key)


def get_random_task(subj_key: str, task_num: int) -> dict:
    """Возвращает случайное задание (учитывая JSON + хардкод)."""
    import random
    module = SUBJECTS[subj_key]["module"]
    hardcoded = []
    if hasattr(module, "TASKS") and task_num in module.TASKS:
        hardcoded = list(module.TASKS[task_num])
    external = EXTERNAL_TASKS.get(subj_key, {}).get(task_num, [])
    pool = hardcoded + external
    if not pool:
        return module.get_random_task(task_num)  # вернёт «нет задания»
    return random.choice(pool)


def get_available_task_numbers(subj_key: str) -> list[int]:
    """Все номера, для которых есть хоть одно задание."""
    module = SUBJECTS[subj_key]["module"]
    nums = set(module.get_task_numbers())
    nums.update(EXTERNAL_TASKS.get(subj_key, {}).keys())
    return sorted(nums)


# ═════════════════════════════════════════════════════════════════
# /start
# ═════════════════════════════════════════════════════════════════
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.clear()
    text = (
        "👋 Привет! Я бот для подготовки к *ОГЭ*.\n\n"
        "Выбери предмет, к которому хочешь готовиться:"
    )
    keyboard = [
        [InlineKeyboardButton(s["name"], callback_data=f"subj_{k}")]
        for k, s in SUBJECTS.items()
    ]
    await _send(update, text, InlineKeyboardMarkup(keyboard))
    return CHOOSE_SUBJECT


# ═════════════════════════════════════════════════════════════════
# Выбор предмета
# ═════════════════════════════════════════════════════════════════
async def choose_subject(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()

    subj_key = query.data.replace("subj_", "")
    context.user_data["subject"] = subj_key
    module = SUBJECTS[subj_key]["module"]
    name = SUBJECTS[subj_key]["name"]

    if not module.is_ready():
        await query.edit_message_text(
            f"{name}\n\n⚠️ Этот предмет пока в разработке.\n"
            "Нажми /start чтобы выбрать другой."
        )
        return ConversationHandler.END

    text = f"*{name}*\n\nЧто хочешь делать?"
    keyboard = [
        [InlineKeyboardButton("✏️ Решать задания", callback_data="action_solve")],
        [InlineKeyboardButton("📚 Конспекты", callback_data="action_conspect")],
        [InlineKeyboardButton("📖 Обозначения", callback_data="action_defs")],
    ]
    # Для русского — отдельный пункт «Тренировка изложения/сочинения»
    if subj_key == "russian" and ai_client.is_configured():
        keyboard.append([InlineKeyboardButton("✍️ Изложение / Сочинение",
                                              callback_data="action_essay")])
    keyboard.append([InlineKeyboardButton("🔙 Сменить предмет", callback_data="action_back")])

    await query.edit_message_text(
        text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="Markdown"
    )
    return CHOOSE_ACTION


# ═════════════════════════════════════════════════════════════════
# Выбор действия
# ═════════════════════════════════════════════════════════════════
async def choose_action(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    action = query.data.replace("action_", "")

    subj_key = context.user_data.get("subject")
    if not subj_key:
        return await start(update, context)

    module = SUBJECTS[subj_key]["module"]

    if action == "back":
        return await start(update, context)

    if action == "back_menu":
        return await back_to_menu(update, context)

    # ── Конспекты ──
    if action == "conspect":
        topics = module.get_conspect_topics()
        if not topics:
            await query.edit_message_text("📚 Конспекты пока не добавлены.")
            return ConversationHandler.END
        keyboard = [[InlineKeyboardButton(name, callback_data=f"conspect_{k}")]
                    for k, name in topics.items()]
        keyboard.append([InlineKeyboardButton("🔙 Назад", callback_data="action_back_menu")])
        await query.edit_message_text(
            "📚 *Конспекты*\n\nВыбери тему:",
            reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="Markdown",
        )
        return READING_CONSPECT

    # ── Обозначения ──
    if action == "defs":
        get_cats = getattr(module, "get_definition_categories", None)
        if not callable(get_cats):
            await query.edit_message_text("📖 Обозначения пока не добавлены.")
            return CHOOSE_ACTION
        categories = get_cats()
        if not categories:
            await query.edit_message_text("📖 Обозначения пока не добавлены.")
            return ConversationHandler.END
        keyboard = [[InlineKeyboardButton(name, callback_data=f"def_{k}")]
                    for k, name in categories.items()]
        if callable(getattr(module, "search_definitions", None)):
            keyboard.append([InlineKeyboardButton("🔎 Найти символ",
                                                  callback_data="action_defsearch")])
        keyboard.append([InlineKeyboardButton("🔙 Назад", callback_data="action_back_menu")])
        await query.edit_message_text(
            "📖 *Обозначения*\n\nВыбери раздел или нажми «Найти символ»:",
            reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="Markdown",
        )
        return READING_CONSPECT

    if action == "defsearch":
        await query.edit_message_text(
            "🔎 *Поиск обозначения*\n\nВведи букву или часть слова.",
            parse_mode="Markdown",
        )
        return SEARCH_DEFINITION

    # ── Тренировка изложения/сочинения (только русский) ──
    if action == "essay":
        keyboard = [
            [InlineKeyboardButton("📝 Сжатое изложение (зад. 1)",
                                  callback_data="essay_izlozhenie")],
            [InlineKeyboardButton("✍️ Сочинение 13.3", callback_data="essay_soch_13_3")],
            [InlineKeyboardButton("🔙 Назад", callback_data="action_back_menu")],
        ]
        await query.edit_message_text(
            "✍️ *Тренировка письменных работ*\n\n"
            "Я проверю твою работу через AI по критериям ФИПИ. "
            "Учти: это вспомогательная проверка, на экзамене оценивают эксперты.",
            reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="Markdown",
        )
        return CHOOSE_ACTION

    if action == "back_menu":
        return await back_to_menu(update, context)

    # ── Решать задания ──
    if action == "solve":
        nums = get_available_task_numbers(subj_key)
        keyboard = []
        row = []
        for num in nums:
            row.append(InlineKeyboardButton(str(num), callback_data=f"task_{num}"))
            if len(row) == 5:
                keyboard.append(row); row = []
        if row:
            keyboard.append(row)
        keyboard.append([InlineKeyboardButton("🔙 Назад", callback_data="action_back_menu")])
        await query.edit_message_text(
            "✏️ *Выбери номер задания:*",
            reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="Markdown",
        )
        return CHOOSE_TASK_NUM

    return CHOOSE_ACTION


# ═════════════════════════════════════════════════════════════════
# Запуск тренировки изложения/сочинения
# ═════════════════════════════════════════════════════════════════
async def essay_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    kind = query.data  # essay_izlozhenie / essay_soch_13_3

    subj_key = context.user_data.get("subject")
    module = SUBJECTS[subj_key]["module"]

    if kind == "essay_izlozhenie":
        # Берём случайный текст-источник из russian.IZLOZHENIE_TEXTS (если есть)
        texts = getattr(module, "IZLOZHENIE_TEXTS", [])
        if not texts:
            await query.edit_message_text(
                "⚠️ Тексты для изложения пока не добавлены."
            )
            return ConversationHandler.END
        import random
        item = random.choice(texts)
        context.user_data["essay_kind"] = "izlozhenie"
        context.user_data["essay_source"] = item["text"]
        await query.edit_message_text(
            "📝 *Сжатое изложение*\n\n"
            "Прочитай текст ниже и напиши сжатое изложение в одном сообщении.\n"
            "Объём — не менее 70 слов. У тебя должно остаться 3 микротемы.\n\n"
            f"*ТЕКСТ:*\n\n{item['text']}",
            parse_mode="Markdown",
        )
        return WAITING_IZLOZHENIE

    if kind == "essay_soch_13_3":
        themes = getattr(module, "SOCHINENIE_THEMES_13_3", [])
        if not themes:
            await query.edit_message_text("⚠️ Темы сочинения 13.3 пока не добавлены.")
            return ConversationHandler.END
        import random
        theme = random.choice(themes)
        context.user_data["essay_kind"] = "sochinenie_13_3"
        context.user_data["essay_task"] = theme["task"]
        context.user_data["essay_source"] = theme.get("source", "")
        msg = f"✍️ *Сочинение 13.3*\n\n{theme['task']}"
        if theme.get("source"):
            msg += f"\n\n*ТЕКСТ-ИСТОЧНИК:*\n\n{theme['source']}"
        msg += "\n\n✍️ Напиши сочинение (минимум 70 слов) и пришли его одним сообщением."
        await query.edit_message_text(msg, parse_mode="Markdown")
        return WAITING_SOCHINENIE

    return CHOOSE_ACTION


# ═════════════════════════════════════════════════════════════════
# Получение изложения от пользователя
# ═════════════════════════════════════════════════════════════════
async def receive_izlozhenie(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user_text = update.message.text.strip()
    source = context.user_data.get("essay_source", "")

    word_count = len(user_text.split())
    if word_count < 50:
        await update.message.reply_text(
            f"⚠️ Изложение слишком короткое ({word_count} слов). "
            "Минимум — 70 слов. Перепиши и пришли заново."
        )
        return WAITING_IZLOZHENIE

    await update.message.reply_text("🔍 Проверяю изложение через AI… (10-30 секунд)")
    result = ai_checker.check_izlozhenie(source, user_text)

    keyboard = [
        [InlineKeyboardButton("📝 Ещё одно изложение", callback_data="essay_izlozhenie")],
        [InlineKeyboardButton("🔙 В меню", callback_data="action_back_menu")],
    ]
    for chunk in _split_text(result, 4000):
        await update.message.reply_text(chunk)
    await update.message.reply_text(
        f"📊 *Твой объём:* {word_count} слов",
        reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="Markdown",
    )
    return CHOOSE_ACTION


# ═════════════════════════════════════════════════════════════════
# Получение сочинения от пользователя
# ═════════════════════════════════════════════════════════════════
async def receive_sochinenie(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user_text = update.message.text.strip()
    task_text = context.user_data.get("essay_task", "")
    source = context.user_data.get("essay_source", "") or None

    word_count = len(user_text.split())
    if word_count < 50:
        await update.message.reply_text(
            f"⚠️ Сочинение слишком короткое ({word_count} слов). Минимум — 70."
        )
        return WAITING_SOCHINENIE

    await update.message.reply_text("🔍 Проверяю сочинение через AI… (15-40 секунд)")
    result = ai_checker.check_sochinenie(task_text, source, user_text, variant="13.3")

    keyboard = [
        [InlineKeyboardButton("✍️ Ещё одно сочинение", callback_data="essay_soch_13_3")],
        [InlineKeyboardButton("🔙 В меню", callback_data="action_back_menu")],
    ]
    for chunk in _split_text(result, 4000):
        await update.message.reply_text(chunk)
    await update.message.reply_text(
        f"📊 *Твой объём:* {word_count} слов",
        reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="Markdown",
    )
    return CHOOSE_ACTION


# ═════════════════════════════════════════════════════════════════
# Прочее: возврат, конспект, определения, поиск
# ═════════════════════════════════════════════════════════════════
async def back_to_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Назад в меню действий предмета."""
    subj_key = context.user_data.get("subject")
    if not subj_key:
        return await start(update, context)

    name = SUBJECTS[subj_key]["name"]
    text = f"*{name}*\n\nЧто хочешь делать?"
    keyboard = [
        [InlineKeyboardButton("✏️ Решать задания", callback_data="action_solve")],
        [InlineKeyboardButton("📚 Конспекты", callback_data="action_conspect")],
        [InlineKeyboardButton("📖 Обозначения", callback_data="action_defs")],
    ]
    if subj_key == "russian" and ai_client.is_configured():
        keyboard.append([InlineKeyboardButton("✍️ Изложение / Сочинение",
                                              callback_data="action_essay")])
    keyboard.append([InlineKeyboardButton("🔙 Сменить предмет", callback_data="action_back")])

    if update.callback_query:
        await update.callback_query.edit_message_text(
            text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="Markdown"
        )
    else:
        await update.message.reply_text(
            text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="Markdown"
        )
    return CHOOSE_ACTION


async def show_conspect(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    topic_key = query.data.replace("conspect_", "")
    subj_key = context.user_data.get("subject")
    module = SUBJECTS[subj_key]["module"]
    text = module.get_conspect(topic_key)

    keyboard = [
        [InlineKeyboardButton("📚 Другая тема", callback_data="action_conspect")],
        [InlineKeyboardButton("🔙 В меню", callback_data="action_back_menu")],
    ]
    chunks = _split_text(text, 4000)
    for i, chunk in enumerate(chunks):
        if i == len(chunks) - 1:
            await query.message.reply_text(
                chunk, parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup(keyboard),
            )
        else:
            await query.message.reply_text(chunk, parse_mode="Markdown")
    return READING_CONSPECT


async def show_definitions(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    cat_key = query.data.replace("def_", "")
    subj_key = context.user_data.get("subject")
    module = SUBJECTS[subj_key]["module"]
    text = module.get_definitions(cat_key)

    keyboard = [
        [InlineKeyboardButton("📖 К разделам", callback_data="action_defs")],
        [InlineKeyboardButton("🔙 В меню", callback_data="action_back_menu")],
    ]
    chunks = _split_text(text, 4000)
    for i, chunk in enumerate(chunks):
        if i == len(chunks) - 1:
            await query.message.reply_text(
                chunk, parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup(keyboard),
            )
        else:
            await query.message.reply_text(chunk, parse_mode="Markdown")
    return READING_CONSPECT


async def search_definition_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query_text = update.message.text.strip()
    subj_key = context.user_data.get("subject")
    if not subj_key:
        await update.message.reply_text("⚠️ Сессия истекла. Нажми /start")
        return ConversationHandler.END

    module = SUBJECTS[subj_key]["module"]
    search = getattr(module, "search_definitions", None)
    if not callable(search):
        await update.message.reply_text("⚠️ Поиск недоступен.")
        return ConversationHandler.END

    if len(query_text) > 50:
        await update.message.reply_text("⚠️ Слишком длинный запрос.")
        return SEARCH_DEFINITION

    results = search(query_text)
    keyboard = [
        [InlineKeyboardButton("🔎 Искать ещё", callback_data="action_defsearch")],
        [InlineKeyboardButton("📖 К разделам", callback_data="action_defs")],
        [InlineKeyboardButton("🔙 В меню", callback_data="action_back_menu")],
    ]
    if not results:
        await update.message.reply_text(
            f"❌ По запросу `{query_text}` ничего не найдено.",
            parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard),
        )
        return CHOOSE_ACTION

    safe_q = query_text.replace("_", "\\_").replace("*", "\\*").replace("`", "")
    lines = [f"🔎 По запросу `{safe_q}` найдено: *{len(results)}*\n"]
    for cat_name, item in results[:15]:
        if len(item) == 5:
            symbol, name, unit, formula, mistake = item
        else:
            symbol, name, unit, formula = item
            mistake = None
        safe_sym = symbol.replace("_", "\\_").replace("*", "\\*")
        unit_part = f"[{unit}]" if unit else ""
        lines.append(f"\n📂 _{cat_name}_")
        lines.append(f"• *{safe_sym}* — {name} {unit_part}")
        if formula and formula != "—":
            lines.append(f"  ↳ `{formula}`")
        if mistake:
            lines.append(f"  ⚠️ _{mistake.replace('_', chr(92)+'_')}_")
    if len(results) > 15:
        lines.append(f"\n_…и ещё {len(results) - 15} результатов._")

    text = "\n".join(lines)
    chunks = _split_text(text, 4000)
    for i, chunk in enumerate(chunks):
        if i == len(chunks) - 1:
            await update.message.reply_text(
                chunk, parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup(keyboard),
            )
        else:
            await update.message.reply_text(chunk, parse_mode="Markdown")
    return CHOOSE_ACTION


# ═════════════════════════════════════════════════════════════════
# Решение заданий
# ═════════════════════════════════════════════════════════════════
async def choose_task(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    task_num = int(query.data.replace("task_", ""))
    context.user_data["task_num"] = task_num
    subj_key = context.user_data["subject"]

    task = get_random_task(subj_key, task_num)
    context.user_data["current_task"] = task

    text = f"📝 *Задание №{task_num}*\n\n{task['question']}\n\n"

    if task.get("no_auto_check"):
        text += (
            "ℹ️ _Это задание из открытого банка ФИПИ. Эталонного ответа нет — "
            "я проверю твой ответ через AI._\n\n"
        )

    text += "✍️ Напиши свой ответ"
    if task_num in (17, 21, 22, 25):  # развёрнутые задания
        text += " или пришли *фото с решением*."
    else:
        text += "."

    # Если есть картинки — присылаем
    if task.get("image_urls"):
        await query.message.reply_text(text, parse_mode="Markdown")
        for img_path in task["image_urls"][:5]:
            try:
                # Если это путь до файла в data/<subject>/images/
                from pathlib import Path
                full = Path(DATA_DIR) / subj_key / img_path
                if full.exists():
                    with open(full, "rb") as f:
                        await query.message.reply_photo(f)
                else:
                    await query.message.reply_text(f"🖼 {img_path}")
            except Exception as e:
                logger.warning("Не смог отправить картинку %s: %s", img_path, e)
    else:
        await query.edit_message_text(text, parse_mode="Markdown")

    return WAITING_ANSWER


async def check_answer(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Проверка текстового ответа."""
    user_answer = update.message.text.strip()
    task = context.user_data.get("current_task")
    task_num = context.user_data.get("task_num")
    subj_key = context.user_data.get("subject")

    if not task or not subj_key:
        await update.message.reply_text("⚠️ Задание не найдено. Нажми /start")
        return ConversationHandler.END

    module = SUBJECTS[subj_key]["module"]

    # Если у задания нет эталонного ответа — проверяем через AI
    if task.get("no_auto_check") and ai_client.is_configured():
        await update.message.reply_text("🔍 Проверяю через AI…")
        result = ai_checker.check_open_task(
            task["question"], user_answer,
            subject=SUBJECTS[subj_key]["name"],
        )
        for chunk in _split_text(result, 4000):
            await update.message.reply_text(chunk)
        await _send_next_buttons(update, task_num)
        return CHOOSE_TASK_NUM

    # Иначе — стандартная автопроверка
    is_correct, feedback = module.check_answer(task, user_answer)
    if is_correct:
        text = "✅ *Правильно!*\n\n"
    else:
        text = "❌ *Неправильно.*\n\n"
        text += f"Твой ответ: `{user_answer}`\n"
        text += f"Правильный: `{task['answer']}`\n\n"
    if feedback:
        text += f"📖 *Пояснение:*\n{feedback}\n\n"
    if task.get("best_answer"):
        text += f"🏆 *Лучший вариант:*\n{task['best_answer']}\n\n"

    keyboard = [
        [InlineKeyboardButton("▶️ Следующее", callback_data=f"task_{task_num}")],
        [InlineKeyboardButton("🔢 Другой номер", callback_data="action_solve")],
        [InlineKeyboardButton("🔙 В меню", callback_data="action_back_menu")],
    ]
    await update.message.reply_text(
        text, parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )
    return CHOOSE_TASK_NUM


async def receive_photo_answer(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Получение фото с решением — отправляется на AI-проверку."""
    if not ai_client.is_configured():
        await update.message.reply_text(
            "⚠️ Проверка фото требует подключения OpenRouter API.\n"
            "Добавь ключ в config.py и перезапусти бота."
        )
        return WAITING_ANSWER

    task = context.user_data.get("current_task")
    task_num = context.user_data.get("task_num")
    if not task:
        await update.message.reply_text("⚠️ Задание не найдено.")
        return ConversationHandler.END

    await update.message.reply_text("📸 Получил фото. Распознаю и проверяю… (20-60 сек)")

    # Скачиваем фото в base64
    photo = update.message.photo[-1]  # самый большой размер
    file = await context.bot.get_file(photo.file_id)
    bio = BytesIO()
    await file.download_to_memory(out=bio)
    bio.seek(0)
    image_b64 = base64.b64encode(bio.read()).decode("ascii")

    result = ai_checker.check_photo_solution(
        image_b64, task_context=task["question"], mime="image/jpeg",
    )

    for chunk in _split_text(result, 4000):
        await update.message.reply_text(chunk)
    await _send_next_buttons(update, task_num)
    return CHOOSE_TASK_NUM


async def _send_next_buttons(update: Update, task_num: int):
    keyboard = [
        [InlineKeyboardButton("▶️ Следующее", callback_data=f"task_{task_num}")],
        [InlineKeyboardButton("🔢 Другой номер", callback_data="action_solve")],
        [InlineKeyboardButton("🔙 В меню", callback_data="action_back_menu")],
    ]
    await update.message.reply_text(
        "Что дальше?", reply_markup=InlineKeyboardMarkup(keyboard),
    )


# ═════════════════════════════════════════════════════════════════
# Утилиты
# ═════════════════════════════════════════════════════════════════
async def _send(update: Update, text: str, markup=None):
    if update.callback_query:
        await update.callback_query.edit_message_text(
            text, reply_markup=markup, parse_mode="Markdown"
        )
    elif update.message:
        await update.message.reply_text(
            text, reply_markup=markup, parse_mode="Markdown"
        )


def _split_text(text: str, max_len: int = 4000) -> list[str]:
    if len(text) <= max_len:
        return [text]
    chunks = []
    current = ""
    for line in text.split("\n"):
        if len(current) + len(line) + 1 > max_len:
            chunks.append(current)
            current = line
        else:
            current += "\n" + line if current else line
    if current:
        chunks.append(current)
    return chunks


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text("👋 Пока! /start чтобы начать заново.")
    return ConversationHandler.END


# ═════════════════════════════════════════════════════════════════
# Запуск
# ═════════════════════════════════════════════════════════════════
def main():
    load_external_tasks()

    app = Application.builder().token(BOT_TOKEN).build()

    conv = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            CHOOSE_SUBJECT: [
                CallbackQueryHandler(choose_subject, pattern=r"^subj_"),
            ],
            CHOOSE_ACTION: [
                CallbackQueryHandler(choose_action, pattern=r"^action_"),
                CallbackQueryHandler(show_conspect, pattern=r"^conspect_"),
                CallbackQueryHandler(show_definitions, pattern=r"^def_"),
                CallbackQueryHandler(essay_start, pattern=r"^essay_"),
            ],
            CHOOSE_TASK_NUM: [
                CallbackQueryHandler(choose_task, pattern=r"^task_\d+"),
                CallbackQueryHandler(choose_action, pattern=r"^action_"),
            ],
            WAITING_ANSWER: [
                MessageHandler(filters.PHOTO, receive_photo_answer),
                MessageHandler(filters.TEXT & ~filters.COMMAND, check_answer),
            ],
            WAITING_IZLOZHENIE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_izlozhenie),
            ],
            WAITING_SOCHINENIE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_sochinenie),
            ],
            READING_CONSPECT: [
                CallbackQueryHandler(show_conspect, pattern=r"^conspect_"),
                CallbackQueryHandler(show_definitions, pattern=r"^def_"),
                CallbackQueryHandler(choose_action, pattern=r"^action_"),
            ],
            SEARCH_DEFINITION: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, search_definition_handler),
                CallbackQueryHandler(choose_action, pattern=r"^action_"),
            ],
        },
        fallbacks=[CommandHandler("start", start), CommandHandler("cancel", cancel)],
        allow_reentry=True,
    )
    app.add_handler(conv)
    logger.info("Бот запущен!")
    app.run_polling()


if __name__ == "__main__":
    main()
