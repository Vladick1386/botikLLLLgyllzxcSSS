"""
Конфигурация бота.

Все секреты лучше задавать через переменные окружения.
Если переменной нет — берётся значение из _HARDCODED_*.
"""

import os

# ─── Telegram ────────────────────────────────────────────────────
_HARDCODED_TOKEN = "8732800700:AAGXeQHyiGgRIcgj7Pkw3u0YL4tfw9U-Hqg"
BOT_TOKEN = os.environ.get("BOT_TOKEN", _HARDCODED_TOKEN)

# ─── OpenRouter (для проверки сочинений/изложений и фото-ответов) ─
# Получи ключ на https://openrouter.ai/keys
# Если оставишь пустым — AI-функции будут отключены, бот всё равно работает.
_HARDCODED_OPENROUTER_KEY = "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"
OPENROUTER_API_KEY = os.environ.get("OPENROUTER_API_KEY", _HARDCODED_OPENROUTER_KEY)

# Модель для проверки сочинений и текстовых заданий.
# Хороший баланс цена/качество: anthropic/claude-3.5-sonnet
# Дешевле: google/gemini-2.0-flash-001, openai/gpt-4o-mini
# Для русского языка лучше Claude или GPT-4o.
OPENROUTER_TEXT_MODEL = os.environ.get(
    "OPENROUTER_TEXT_MODEL",
    "anthropic/claude-3.5-sonnet",
)

# Модель для разбора фото (с задачами/решениями). Должна уметь vision.
OPENROUTER_VISION_MODEL = os.environ.get(
    "OPENROUTER_VISION_MODEL",
    "anthropic/claude-3.5-sonnet",
)

# Бесплатные модели (часто перегружены, но без оплаты):
# "google/gemini-2.0-flash-exp:free", "meta-llama/llama-3.2-90b-vision-instruct:free"

# ─── Пути ────────────────────────────────────────────────────────
DATA_DIR = os.environ.get("DATA_DIR", os.path.join(os.path.dirname(__file__), "data"))

# ─── Флаги ───────────────────────────────────────────────────────
AI_CHECK_ENABLED = bool(OPENROUTER_API_KEY)
