"""
Верификация сгенерированных задач по физике.
Парсит explanation и пересчитывает арифметику, чтобы убедиться,
что ответы корректны.
"""
import json
import re
from pathlib import Path

DATA = Path(__file__).resolve().parent / "data" / "physics" / "tasks"

errors = 0
checked = 0

for f in sorted(DATA.glob("*.json")):
    with open(f, encoding="utf-8") as fh:
        tasks = json.load(fh)
    print(f"\n{f.name}: {len(tasks)} задач")
    for t in tasks[:3]:  # первые 3 от каждого типа — для проверки
        checked += 1
        ans = t["answer"].replace(",", ".")
        expl = t["explanation"]
        # ищем "= NUMBER" в конце explanation
        m = re.findall(r"=\s*(-?\d+(?:[.,]\d+)?)", expl)
        if not m:
            print(f"  [SKIP] {t['id']}: нет числа в expl")
            continue
        last = m[-1].replace(",", ".")
        try:
            ans_num = float(ans)
            last_num = float(last)
        except ValueError:
            continue
        if abs(ans_num - last_num) > max(0.01, abs(ans_num) * 0.001):
            print(f"  ❌ {t['id']}: ответ {ans} ≠ последнее число в expl {last}")
            print(f"     Q: {t['question'][:80]}")
            print(f"     E: {expl[:120]}")
            errors += 1

print(f"\n=== Проверено {checked} задач, ошибок: {errors} ===")
