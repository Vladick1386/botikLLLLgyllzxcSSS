# Парсеры заданий ФИПИ

В этой папке — два независимых парсера. Они **не запускаются ботом сами по себе**.
Их запускают вручную с твоей машины (или с любого сервера с интернетом),
чтобы скачать задания, а потом кладут результат в `data/<предмет>/tasks/`.

## 1. `parse_openfipi.py` — для ИНФОРМАТИКИ

Источник: https://openfipi.devinf.ru/tasks_oge/
Покрытие: только информатика, ~1766 заданий с ответами и решениями.

Это **зеркало** ФИПИ, где задания уже распарсены в HTML-текст
(а не картинками, как у самого ФИПИ).

```bash
pip install requests beautifulsoup4
python fipi_parser/parse_openfipi.py --out data/informatics/tasks
```

После запуска в `data/informatics/tasks/` появятся файлы вида:
```
data/informatics/tasks/01.json   ← все задания №1
data/informatics/tasks/02.json   ← все задания №2
...
```

## 2. `parse_fipi_direct.py` — для ФИЗИКИ / МАТЕМАТИКИ / РУССКОГО

Источник: https://oge.fipi.ru/bank/index.php
Покрытие: всё, что есть на ФИПИ (физика, математика, русский, и т.д.).

⚠️ Особенности:
- Задания на ФИПИ часто содержат **картинки** (графики, схемы) — парсер их скачает
  и сохранит ссылку, но сам текст без картинок будет неполным.
- В открытом банке **ответов нет** — их добавляет пользователь.
  Поэтому из ФИПИ вытащим только условия. Ответы придётся добавлять вручную
  (или прогонять через AI-проверку при выдаче).
- На ФИПИ есть anti-bot защита — парсер делает паузы, использует cookies.
  Если заблокируют — поменяй User-Agent и попробуй через VPN.

```bash
python fipi_parser/parse_fipi_direct.py --subject physics --out data/physics/tasks
python fipi_parser/parse_fipi_direct.py --subject math    --out data/math/tasks
python fipi_parser/parse_fipi_direct.py --subject russian --out data/russian/tasks
```

## Формат сохраняемых файлов

Каждый JSON выглядит так (это формат, который понимает наш бот):

```json
[
  {
    "id": "fipi_phys_1_AB12CD",
    "question": "Текст задания…",
    "answer": "243",
    "answer_aliases": [],
    "explanation": "",
    "best_answer": "",
    "image_urls": ["https://oge.fipi.ru/.../image1.png"],
    "source": "fipi"
  },
  …
]
```

Бот при загрузке заданий мёрджит JSON-ы из `data/<предмет>/tasks/` со встроенными
хардкод-заданиями из `subjects/<предмет>.py`.

## Что делать, если парсер не работает

ФИПИ обновляет вёрстку — селекторы могут поломаться. Открой страницу с
заданием в браузере, нажми F12, посмотри, в каком теге лежит текст задания,
и поправь CSS-селектор в `parse_fipi_direct.py` (там есть комментарии).

Парсер `parse_openfipi.py` стабильнее — у devinf.ru вёрстка проще.
