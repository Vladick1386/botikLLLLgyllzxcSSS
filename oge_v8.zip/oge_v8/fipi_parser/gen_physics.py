"""
Генератор расчётных задач по физике для ОГЭ.

Принцип: формула + диапазон параметров + код для расчёта ответа.
Это ГАРАНТИРУЕТ правильность ответа, потому что каждое значение считается
честным Python-кодом, а не сочиняется текстом.

Запуск:
    python -m fipi_parser.gen_physics  # создаст data/physics/tasks/*.json

Генерирует ~50 вариантов на каждое задание. Все ответы вычислены кодом.
"""

import json
import random
import os
from pathlib import Path

random.seed(42)  # детерминированно для воспроизводимости

OUT = Path(__file__).resolve().parent.parent / "data" / "physics" / "tasks"
OUT.mkdir(parents=True, exist_ok=True)

g = 10  # м/с² (стандарт для ОГЭ)


def fmt(x: float, digits: int = 2) -> str:
    """Форматирование в стиле ОГЭ: запятая, без лишних нулей."""
    if abs(x - round(x)) < 1e-9:
        return str(int(round(x)))
    s = f"{x:.{digits}f}".rstrip("0").rstrip(".")
    return s.replace(".", ",")


def aliases(s: str) -> list[str]:
    """Допустимые формы ответа: с точкой, с запятой, без хвостовых нулей."""
    base = s.replace(",", ".")
    out = {s, base}
    # без ведущего 0 ("0,5" → ",5") — не добавляем, ОГЭ требует «0,5»
    return list(out - {s})


# ═══════════════════════════════════════════════════════════════
# ЗАДАНИЕ 6: расчёт по простой формуле
# ═══════════════════════════════════════════════════════════════
def gen_task_6() -> list[dict]:
    out = []
    # Тип A: Свободное падение, v = g*t
    for _ in range(8):
        gp = round(random.uniform(1.6, 9.8), 1)  # ускорение на разных планетах
        t = random.randint(2, 8)
        v = gp * t
        out.append({
            "question": (
                f"Ускорение свободного падения вблизи поверхности планеты равно "
                f"{fmt(gp, 1)} м/с². Какую скорость приобретёт камень за {t} с "
                f"падения из состояния покоя?\n\nОтвет в м/с:"
            ),
            "answer": fmt(v),
            "answer_aliases": aliases(fmt(v)),
            "explanation": f"v = g·t = {fmt(gp, 1)} · {t} = {fmt(v)} м/с",
            "best_answer": fmt(v),
        })

    # Тип B: Гидростатика, p = ρgh — найти ρ
    for _ in range(8):
        rho = random.choice([800, 900, 1000, 1100, 1200, 1300, 1500, 1800, 2000, 2500])
        h_cm = random.choice([10, 20, 25, 30, 40, 50, 60])
        h = h_cm / 100
        p = rho * g * h  # Па
        out.append({
            "question": (
                f"Столб жидкости высотой {h_cm} см оказывает давление {fmt(p)} Па. "
                f"Чему равна плотность жидкости? (g = 10 м/с²)\n\nОтвет в кг/м³:"
            ),
            "answer": fmt(rho),
            "answer_aliases": [],
            "explanation": (
                f"p = ρ·g·h → ρ = p/(g·h) = {fmt(p)} / (10 · {fmt(h, 2)}) = {fmt(rho)} кг/м³"
            ),
            "best_answer": fmt(rho),
        })

    # Тип C: Гидростатика, p = ρgh — найти p
    for _ in range(8):
        rho = random.choice([1000, 1030, 13600, 800, 900])  # вода/морская/ртуть/масла
        names = {1000: "пресная вода", 1030: "морская вода", 13600: "ртуть",
                 800: "керосин", 900: "масло"}
        h_m = round(random.uniform(0.5, 8.0), 1)
        p = rho * g * h_m
        out.append({
            "question": (
                f"Найди давление, которое оказывает столб жидкости ({names[rho]}, "
                f"плотность {rho} кг/м³) высотой {fmt(h_m, 1)} м. (g = 10 м/с²)\n\n"
                f"Ответ в Па:"
            ),
            "answer": fmt(p),
            "answer_aliases": [],
            "explanation": f"p = ρ·g·h = {rho} · 10 · {fmt(h_m, 1)} = {fmt(p)} Па",
            "best_answer": fmt(p),
        })

    # Тип D: Падение с высоты, h = gt²/2 → найти t
    import math
    for _ in range(8):
        h_m = random.choice([5, 20, 45, 80, 125, 180, 320])
        t = math.sqrt(2 * h_m / g)
        # подбираем h, чтобы t было целым
        out.append({
            "question": (
                f"С высоты {h_m} м без начальной скорости падает камень. "
                f"Сколько времени он будет лететь до земли? (g = 10 м/с², "
                f"сопротивлением воздуха пренебречь)\n\nОтвет в с:"
            ),
            "answer": fmt(t),
            "answer_aliases": aliases(fmt(t)),
            "explanation": f"h = g·t²/2 → t = √(2h/g) = √(2·{h_m}/10) = {fmt(t)} с",
            "best_answer": fmt(t),
        })

    # Тип E: бросок вверх, v₀ = g·t (время до верхней точки)
    for _ in range(8):
        v0 = random.choice([10, 15, 20, 25, 30, 40, 50])
        t = v0 / g
        out.append({
            "question": (
                f"Тело брошено вертикально вверх со скоростью {v0} м/с. "
                f"Через сколько секунд оно достигнет верхней точки? (g = 10 м/с²)\n\n"
                f"Ответ в с:"
            ),
            "answer": fmt(t),
            "answer_aliases": aliases(fmt(t)),
            "explanation": f"В верхней точке v=0. v=v₀−g·t → t = v₀/g = {v0}/10 = {fmt(t)} с",
            "best_answer": fmt(t),
        })

    # Тип F: F = ma — найти F
    for _ in range(10):
        m = random.choice([0.5, 1, 1.5, 2, 2.5, 3, 4, 5, 8, 10])
        a = random.choice([0.5, 1, 1.5, 2, 2.5, 3, 4])
        F = m * a
        out.append({
            "question": (
                f"Тело массой {fmt(m)} кг движется с ускорением {fmt(a)} м/с². "
                f"Какая сила действует на тело?\n\nОтвет в Н:"
            ),
            "answer": fmt(F),
            "answer_aliases": [],
            "explanation": f"F = m·a = {fmt(m)} · {fmt(a)} = {fmt(F)} Н",
            "best_answer": fmt(F),
        })

    # добавляем id
    for i, t in enumerate(out, 1):
        t["id"] = f"phys_gen_6_{i:02d}"
    return out


# ═══════════════════════════════════════════════════════════════
# ЗАДАНИЕ 7: динамика, законы Ньютона, силы
# ═══════════════════════════════════════════════════════════════
def gen_task_7() -> list[dict]:
    out = []
    # a = F/m
    for _ in range(10):
        m_kg = random.choice([0.2, 0.5, 1, 1.5, 2, 2.5, 4, 5])
        F = random.choice([0.4, 1, 2, 5, 10, 20, 25])
        a = F / m_kg
        m_g = m_kg * 1000
        out.append({
            "question": (
                f"Какое ускорение приобретёт тело массой "
                f"{fmt(m_g) if m_kg < 1 else fmt(m_kg)+ ' кг'}"
                f"{' г' if m_kg < 1 else ''} под действием силы {fmt(F)} Н?\n\n"
                f"Ответ в м/с²:"
            ),
            "answer": fmt(a),
            "answer_aliases": aliases(fmt(a)),
            "explanation": (
                f"a = F/m = {fmt(F)} / {fmt(m_kg)} = {fmt(a)} м/с²"
                + (f"\n(не забудь: {fmt(m_g)} г = {fmt(m_kg)} кг)"
                   if m_kg < 1 else "")
            ),
            "best_answer": fmt(a),
        })

    # E_p = mgh
    for _ in range(10):
        m = random.choice([1, 1.5, 2, 2.5, 3, 4, 5, 8, 10])
        h = random.choice([2, 3, 5, 8, 10, 12, 15, 20])
        E = m * g * h
        out.append({
            "question": (
                f"Тело массой {fmt(m)} кг подвешено на высоте {fmt(h)} м. "
                f"Найди потенциальную энергию относительно земли. (g = 10 м/с²)\n\n"
                f"Ответ в Дж:"
            ),
            "answer": fmt(E),
            "answer_aliases": [],
            "explanation": f"E_п = m·g·h = {fmt(m)} · 10 · {fmt(h)} = {fmt(E)} Дж",
            "best_answer": fmt(E),
        })

    # μ = F_тр / N
    for _ in range(10):
        m = random.choice([2, 3, 4, 5, 8, 10, 15, 20])
        N = m * g
        mu = round(random.choice([0.1, 0.15, 0.2, 0.25, 0.3, 0.4, 0.5]), 2)
        F_tr = mu * N
        out.append({
            "question": (
                f"На брусок массой {fmt(m)} кг действует сила трения "
                f"{fmt(F_tr)} Н. Чему равен коэффициент трения? (g = 10 м/с²)\n\n"
                f"Ответ:"
            ),
            "answer": fmt(mu, 2),
            "answer_aliases": aliases(fmt(mu, 2)),
            "explanation": (
                f"N = m·g = {fmt(m)}·10 = {fmt(N)} Н\n"
                f"μ = F_тр/N = {fmt(F_tr)}/{fmt(N)} = {fmt(mu, 2)}"
            ),
            "best_answer": fmt(mu, 2),
        })

    # E_k = mv²/2
    for _ in range(10):
        m = random.choice([0.5, 1, 1.5, 2, 3, 4, 5])
        v = random.choice([2, 3, 4, 5, 6, 8, 10])
        E = m * v * v / 2
        out.append({
            "question": (
                f"Тело массой {fmt(m)} кг движется со скоростью {fmt(v)} м/с. "
                f"Чему равна его кинетическая энергия?\n\nОтвет в Дж:"
            ),
            "answer": fmt(E),
            "answer_aliases": [],
            "explanation": (
                f"E_к = m·v²/2 = {fmt(m)}·{fmt(v)}²/2 = "
                f"{fmt(m)}·{fmt(v*v)}/2 = {fmt(E)} Дж"
            ),
            "best_answer": fmt(E),
        })

    # F_упр = k·x (Гука)
    for _ in range(10):
        k = random.choice([50, 100, 150, 200, 300, 400, 500])
        x_cm = random.choice([2, 4, 5, 8, 10, 15, 20])
        x = x_cm / 100
        F = k * x
        out.append({
            "question": (
                f"Пружина жёсткостью {k} Н/м растянута на {x_cm} см. "
                f"Какая сила упругости возникает в пружине?\n\nОтвет в Н:"
            ),
            "answer": fmt(F),
            "answer_aliases": [],
            "explanation": (
                f"x = {x_cm} см = {fmt(x, 2)} м\n"
                f"F = k·x = {k} · {fmt(x, 2)} = {fmt(F)} Н"
            ),
            "best_answer": fmt(F),
        })

    for i, t in enumerate(out, 1):
        t["id"] = f"phys_gen_7_{i:02d}"
    return out


# ═══════════════════════════════════════════════════════════════
# ЗАДАНИЕ 8: тепловые явления (Q = cmΔT, Q = λm, Q = qm)
# ═══════════════════════════════════════════════════════════════
def gen_task_8() -> list[dict]:
    out = []
    # Q = c·m·ΔT (нагревание)
    # имя в именительном → удельная теплоёмкость, имя в род. падеже для текста
    materials = [
        ("вода",     "воды",     4200),
        ("лёд",      "льда",     2100),
        ("медь",     "меди",     380),
        ("алюминий", "алюминия", 920),
        ("железо",   "железа",   460),
        ("свинец",   "свинца",   130),
        ("серебро",  "серебра",  250),
        ("золото",   "золота",   130),
    ]
    for _ in range(15):
        nom, gen, c = random.choice(materials)
        m = random.choice([0.1, 0.2, 0.5, 1, 1.5, 2, 3, 5])
        dT = random.choice([10, 20, 30, 40, 50, 60])
        Q = c * m * dT
        out.append({
            "question": (
                f"Какое количество теплоты потребуется, чтобы нагреть "
                f"{fmt(m)} кг {gen} на {dT} °C? "
                f"(c = {c} Дж/(кг·°C))\n\n"
                f"Ответ в Дж:"
            ),
            "answer": fmt(Q),
            "answer_aliases": [],
            "explanation": f"Q = c·m·ΔT = {c} · {fmt(m)} · {dT} = {fmt(Q)} Дж",
            "best_answer": fmt(Q),
        })

    # Q = λ·m (плавление)
    melt = [
        ("льда",    330000),
        ("свинца",  25000),
        ("меди",    210000),
        ("стали",   270000),
    ]
    for _ in range(10):
        gen, lam = random.choice(melt)
        m = random.choice([0.1, 0.2, 0.5, 1, 2])
        Q = lam * m
        out.append({
            "question": (
                f"Сколько теплоты нужно, чтобы расплавить {fmt(m)} кг "
                f"{gen}, взятого при температуре плавления? "
                f"(λ = {fmt(lam)} Дж/кг)\n\nОтвет в Дж:"
            ),
            "answer": fmt(Q),
            "answer_aliases": [],
            "explanation": f"Q = λ·m = {fmt(lam)} · {fmt(m)} = {fmt(Q)} Дж",
            "best_answer": fmt(Q),
        })

    # Q = q·m (сгорание топлива)
    fuel = [
        ("спирта",  27e6),
        ("бензина", 46e6),
        ("керосина", 43e6),
        ("угля",    30e6),
        ("дров",    10e6),
        ("нефти",   44e6),
    ]
    for _ in range(10):
        gen, q = random.choice(fuel)
        m = random.choice([0.1, 0.2, 0.5, 1, 2, 5])
        Q = q * m
        out.append({
            "question": (
                f"Сколько теплоты выделится при полном сгорании {fmt(m)} кг "
                f"{gen}? (удельная теплота сгорания {fmt(q)} Дж/кг)\n\n"
                f"Ответ в Дж:"
            ),
            "answer": fmt(Q),
            "answer_aliases": [],
            "explanation": f"Q = q·m = {fmt(q)} · {fmt(m)} = {fmt(Q)} Дж",
            "best_answer": fmt(Q),
        })

    # Q = r·m (парообразование)
    for _ in range(8):
        m = random.choice([0.1, 0.2, 0.5, 1, 2])
        r = 2.3e6
        Q = r * m
        out.append({
            "question": (
                f"Сколько теплоты нужно для превращения {fmt(m)} кг воды в пар "
                f"при температуре кипения? (r = 2,3·10⁶ Дж/кг)\n\nОтвет в Дж:"
            ),
            "answer": fmt(Q),
            "answer_aliases": [],
            "explanation": f"Q = r·m = 2,3·10⁶ · {fmt(m)} = {fmt(Q)} Дж",
            "best_answer": fmt(Q),
        })

    # КПД нагревателя: η = Q_полезн/Q_затрач × 100%
    for _ in range(7):
        m_water = random.choice([1, 2, 3, 5])
        dT = random.choice([20, 30, 50, 80])
        Q_useful = 4200 * m_water * dT
        # топливо
        m_fuel = round(random.choice([0.05, 0.1, 0.2, 0.3, 0.5]), 2)
        q = 46e6  # бензин
        Q_full = q * m_fuel
        if Q_full < Q_useful:
            continue  # пропускаем нереалистичный
        eff = Q_useful / Q_full * 100
        out.append({
            "question": (
                f"Для нагревания {fmt(m_water)} кг воды на {dT} °C "
                f"сожгли {fmt(m_fuel, 2)} кг бензина. Чему равен КПД нагревателя? "
                f"(c_воды = 4200 Дж/(кг·°C), q_бензина = 4,6·10⁷ Дж/кг)\n\n"
                f"Ответ в %, округли до целых:"
            ),
            "answer": fmt(round(eff)),
            "answer_aliases": [fmt(round(eff, 1))],
            "explanation": (
                f"Q_полезн = c·m·ΔT = 4200·{fmt(m_water)}·{dT} = {fmt(Q_useful)} Дж\n"
                f"Q_затрач = q·m = 4,6·10⁷·{fmt(m_fuel, 2)} = {fmt(Q_full)} Дж\n"
                f"η = Q_полезн/Q_затрач · 100% ≈ {fmt(round(eff))}%"
            ),
            "best_answer": fmt(round(eff)),
        })

    for i, t in enumerate(out, 1):
        t["id"] = f"phys_gen_8_{i:02d}"
    return out


# ═══════════════════════════════════════════════════════════════
# ЗАДАНИЕ 9: электричество (закон Ома, мощность, работа тока)
# ═══════════════════════════════════════════════════════════════
def gen_task_9() -> list[dict]:
    out = []
    # I = U/R
    for _ in range(15):
        U = random.choice([6, 9, 12, 24, 36, 48, 110, 220])
        R = random.choice([2, 3, 4, 5, 6, 8, 10, 11, 12, 22, 44])
        if U / R > 100 or U/R < 0.1:
            continue
        I = U / R
        out.append({
            "question": (
                f"К участку цепи с сопротивлением {R} Ом приложено напряжение "
                f"{U} В. Чему равна сила тока?\n\nОтвет в А:"
            ),
            "answer": fmt(I, 2),
            "answer_aliases": aliases(fmt(I, 2)),
            "explanation": f"По закону Ома: I = U/R = {U}/{R} = {fmt(I, 2)} А",
            "best_answer": fmt(I, 2),
        })

    # R = U/I
    for _ in range(12):
        U = random.choice([6, 9, 12, 24, 36, 110, 220])
        I = random.choice([0.5, 1, 1.5, 2, 2.5, 3, 5])
        R = U / I
        out.append({
            "question": (
                f"Сила тока в проводнике {fmt(I)} А при напряжении {U} В. "
                f"Чему равно сопротивление проводника?\n\nОтвет в Ом:"
            ),
            "answer": fmt(R),
            "answer_aliases": aliases(fmt(R)),
            "explanation": f"R = U/I = {U}/{fmt(I)} = {fmt(R)} Ом",
            "best_answer": fmt(R),
        })

    # P = UI
    for _ in range(12):
        U = random.choice([12, 24, 110, 220])
        I = random.choice([0.5, 1, 2, 3, 5, 10])
        P = U * I
        out.append({
            "question": (
                f"В электроприборе сила тока {fmt(I)} А при напряжении {U} В. "
                f"Какую мощность потребляет прибор?\n\nОтвет в Вт:"
            ),
            "answer": fmt(P),
            "answer_aliases": [],
            "explanation": f"P = U·I = {U} · {fmt(I)} = {fmt(P)} Вт",
            "best_answer": fmt(P),
        })

    # Q = I²Rt (закон Джоуля-Ленца)
    for _ in range(11):
        I = random.choice([1, 2, 3, 5])
        R = random.choice([5, 10, 20, 50])
        t = random.choice([60, 120, 300, 600])  # секунды
        Q = I * I * R * t
        out.append({
            "question": (
                f"По проводнику сопротивлением {R} Ом течёт ток {I} А в течение "
                f"{t} с. Сколько теплоты выделится в проводнике?\n\n"
                f"Ответ в Дж:"
            ),
            "answer": fmt(Q),
            "answer_aliases": [],
            "explanation": f"Q = I²·R·t = {I}²·{R}·{t} = {I*I}·{R}·{t} = {fmt(Q)} Дж",
            "best_answer": fmt(Q),
        })

    for i, t in enumerate(out, 1):
        t["id"] = f"phys_gen_9_{i:02d}"
    return out


# ═══════════════════════════════════════════════════════════════
# ЗАДАНИЕ 10: оптика (преломление, фокус, формула линзы)
# ═══════════════════════════════════════════════════════════════
def gen_task_10() -> list[dict]:
    out = []
    # D = 1/F — оптическая сила
    for _ in range(12):
        F_cm = random.choice([10, 20, 25, 40, 50, 100])
        F_m = F_cm / 100
        D = 1 / F_m
        out.append({
            "question": (
                f"Фокусное расстояние линзы {F_cm} см. Чему равна оптическая "
                f"сила линзы?\n\nОтвет в дптр:"
            ),
            "answer": fmt(D),
            "answer_aliases": aliases(fmt(D)),
            "explanation": (
                f"F = {F_cm} см = {fmt(F_m, 2)} м\n"
                f"D = 1/F = 1/{fmt(F_m, 2)} = {fmt(D)} дптр"
            ),
            "best_answer": fmt(D),
        })

    # F = 1/D
    for _ in range(12):
        D = random.choice([1, 2, 2.5, 4, 5, 10])
        F_m = 1 / D
        F_cm = F_m * 100
        out.append({
            "question": (
                f"Оптическая сила линзы {fmt(D)} дптр. Чему равно фокусное "
                f"расстояние?\n\nОтвет в см:"
            ),
            "answer": fmt(F_cm),
            "answer_aliases": [],
            "explanation": (
                f"F = 1/D = 1/{fmt(D)} = {fmt(F_m, 2)} м = {fmt(F_cm)} см"
            ),
            "best_answer": fmt(F_cm),
        })

    # Закон отражения — теоретический ответ
    for _ in range(10):
        ang = random.choice([15, 25, 30, 35, 40, 45, 50, 60, 70])
        out.append({
            "question": (
                f"Угол между падающим лучом и зеркалом равен {ang}°. "
                f"Чему равен угол отражения?\n\n"
                f"(подсказка: угол падения отсчитывается от нормали — перпендикуляра к зеркалу)\n\n"
                f"Ответ в градусах:"
            ),
            "answer": str(90 - ang),
            "answer_aliases": [],
            "explanation": (
                f"Угол падения = 90° − {ang}° = {90-ang}°\n"
                f"По закону отражения угол отражения = углу падения = {90-ang}°"
            ),
            "best_answer": str(90 - ang),
        })

    # Период / частота T = 1/ν
    for _ in range(10):
        nu = random.choice([2, 4, 5, 10, 20, 25, 50, 100])
        T = 1 / nu
        T_ms = T * 1000
        out.append({
            "question": (
                f"Частота колебаний {nu} Гц. Чему равен период колебаний?\n\n"
                f"Ответ в секундах:"
            ),
            "answer": fmt(T, 3),
            "answer_aliases": aliases(fmt(T, 3)),
            "explanation": f"T = 1/ν = 1/{nu} = {fmt(T, 3)} с = {fmt(T_ms)} мс",
            "best_answer": fmt(T, 3),
        })

    for i, t in enumerate(out, 1):
        t["id"] = f"phys_gen_10_{i:02d}"
    return out


# ═══════════════════════════════════════════════════════════════
# ЗАДАНИЕ 11: единицы измерения (тестовое — соответствие)
# ═══════════════════════════════════════════════════════════════
def gen_task_11() -> list[dict]:
    """Это задание — соответствие величина↔единица. Текстовое, не расчётное.
    Здесь делаем 50 вариантов с перетасовкой пар."""
    pairs = [
        ("сила", "Н"),
        ("работа", "Дж"),
        ("мощность", "Вт"),
        ("давление", "Па"),
        ("количество теплоты", "Дж"),
        ("сила тока", "А"),
        ("напряжение", "В"),
        ("сопротивление", "Ом"),
        ("электрический заряд", "Кл"),
        ("ускорение", "м/с²"),
        ("частота", "Гц"),
        ("период", "с"),
        ("импульс", "кг·м/с"),
        ("плотность", "кг/м³"),
        ("оптическая сила", "дптр"),
    ]
    out = []
    for variant in range(50):
        # выберем 3 величины и 5 вариантов единиц (как в ОГЭ)
        chosen = random.sample(pairs, 3)
        all_units = list({u for _, u in pairs})
        # перемешаем единицы и пронумеруем
        # Возьмём 5 единиц, среди которых должны быть 3 нужных
        right_units = [u for _, u in chosen]
        wrong_pool = [u for u in all_units if u not in right_units]
        random.shuffle(wrong_pool)
        units_list = right_units + wrong_pool[:2]
        random.shuffle(units_list)
        # позиции правильных
        ans = "".join(str(units_list.index(u) + 1) for u in right_units)

        text = (
            "Установите соответствие между физическими величинами и их единицами измерения.\n\n"
            "ВЕЛИЧИНА:\n"
            f"А) {chosen[0][0]}\n"
            f"Б) {chosen[1][0]}\n"
            f"В) {chosen[2][0]}\n\n"
            "ЕДИНИЦЫ ИЗМЕРЕНИЯ:\n"
            + "\n".join(f"{i+1}) {u}" for i, u in enumerate(units_list))
            + "\n\nЗапиши 3 цифры (А, Б, В):"
        )
        expl = (
            f"А) {chosen[0][0]} измеряется в {chosen[0][1]} → "
            f"{units_list.index(chosen[0][1])+1}\n"
            f"Б) {chosen[1][0]} измеряется в {chosen[1][1]} → "
            f"{units_list.index(chosen[1][1])+1}\n"
            f"В) {chosen[2][0]} измеряется в {chosen[2][1]} → "
            f"{units_list.index(chosen[2][1])+1}"
        )
        out.append({
            "id": f"phys_gen_11_{variant+1:02d}",
            "question": text,
            "answer": ans,
            "answer_aliases": [],
            "explanation": expl,
            "best_answer": ans,
        })
    return out


# ═══════════════════════════════════════════════════════════════
# Сборка и запись
# ═══════════════════════════════════════════════════════════════
GENERATORS = {
    6: gen_task_6,
    7: gen_task_7,
    8: gen_task_8,
    9: gen_task_9,
    10: gen_task_10,
    11: gen_task_11,
}


def main():
    print("Генератор задач по физике v8\n")
    for num, fn in GENERATORS.items():
        tasks = fn()
        path = OUT / f"{num:02d}.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(tasks, f, ensure_ascii=False, indent=2)
        print(f"  → {path}: {len(tasks)} вариантов")

    print(f"\nГотово. Файлы в {OUT}")


if __name__ == "__main__":
    main()
