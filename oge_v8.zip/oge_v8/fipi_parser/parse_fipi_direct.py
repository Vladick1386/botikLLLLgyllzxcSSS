"""
Парсер открытого банка заданий ФИПИ (oge.fipi.ru/bank/index.php)
для физики, математики, русского.

⚠️ ОСОБЕННОСТИ:
1. На ФИПИ задания часто содержат картинки (рисунки, графики, схемы).
   Парсер скачивает картинки в data/<subject>/images/ и сохраняет ссылки.
2. В открытом банке НЕТ правильных ответов. Парсер вытащит только условия.
   Ответы потом надо проставлять вручную, или прогонять через AI-проверку.
3. На ФИПИ есть anti-bot: если будет 403 — поменяй User-Agent или используй VPN.
4. Вёрстка ФИПИ может меняться. Если селекторы ломаются — открой страницу в
   браузере, посмотри HTML (F12) и поправь функцию parse_task_html().

Запуск:
    pip install requests beautifulsoup4
    python fipi_parser/parse_fipi_direct.py --subject physics --out data/physics/tasks --max-tasks 100

Параметр --max-tasks ограничивает количество скачиваемых заданий, чтобы
сначала проверить, что парсинг работает, а потом качать всё.
"""

from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
import time
from pathlib import Path
from urllib.parse import urljoin, urlparse, parse_qs

try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    print("ОШИБКА: нужно поставить зависимости.")
    print("Запусти: pip install requests beautifulsoup4")
    sys.exit(1)


BASE = "https://oge.fipi.ru"
BANK_URL = BASE + "/bank/index.php"

# Коды предметов в открытом банке ОГЭ.
# Эти коды я подсмотрел в выдаче поисковиков — они стабильные годами,
# но если что-то изменится, открой oge.fipi.ru/bank в браузере, выбери
# предмет, скопируй параметр proj= из URL.
SUBJECT_CODES = {
    "physics":  "B24AFED7DE6AB5BC461219556CCA4F9B",
    "informatics": "74676951F093A0754D74F2D6E7955F06",
    # Для математики и русского коды нужно проверить — они здесь
    # как заглушки, замени на реальные перед запуском.
    # Чтобы найти: открой oge.fipi.ru/bank в браузере, выбери предмет,
    # скопируй ?proj=… из адресной строки.
    "math":     "REPLACE_WITH_MATH_CODE",
    "russian":  "REPLACE_WITH_RUSSIAN_CODE",
}

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0 Safari/537.36"
)


def make_session() -> requests.Session:
    s = requests.Session()
    s.headers.update({
        "User-Agent": USER_AGENT,
        "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
    })
    # Сначала заходим на главную, чтобы получить куки
    try:
        s.get(BASE, timeout=20)
    except requests.RequestException:
        pass
    return s


def fetch_listing(session: requests.Session, proj: str, page: int = 1) -> str:
    """Скачивает страницу-список банка."""
    params = {"proj": proj}
    if page > 1:
        params["page"] = page
    r = session.get(BANK_URL, params=params, timeout=30)
    r.raise_for_status()
    r.encoding = "utf-8"
    return r.text


def parse_listing(html: str) -> list[str]:
    """Возвращает список qid'ов с одной страницы списка."""
    soup = BeautifulSoup(html, "html.parser")
    qids = []
    # На страницах ФИПИ задания идут блоками с классами вроде .qblock,
    # а ссылки на конкретное задание — с параметром qid=
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if "qid=" in href:
            q = parse_qs(urlparse(href).query).get("qid", [None])[0]
            if q and q not in qids:
                qids.append(q)
    return qids


def fetch_task(session: requests.Session, proj: str, qid: str) -> str:
    """Скачивает страницу одного задания."""
    params = {"proj": proj, "qid": qid}
    r = session.get(BANK_URL, params=params, timeout=30)
    r.raise_for_status()
    r.encoding = "utf-8"
    return r.text


def parse_task_html(html: str, qid: str, subject: str,
                    images_dir: Path, session: requests.Session) -> dict | None:
    """Парсит HTML страницы задания.

    ⚠️ Этот метод — самая хрупкая часть парсера. Селекторы основаны
    на типичной вёрстке ФИПИ. Если что-то ломается, открой страницу
    задания в браузере (F12) и поправь поиск.
    """
    soup = BeautifulSoup(html, "html.parser")

    # 1. Текст задания. На ФИПИ обычно есть .param-Текст или похожий блок.
    # Запасной вариант — взять основной body и фильтровать.
    text_block = (
        soup.find("div", class_=re.compile(r"q-?text|task-?text|param-?text", re.I))
        or soup.find("td", class_=re.compile(r"q-?text", re.I))
    )
    if not text_block:
        # Эвристика: ищем самый длинный <div> с текстом, в котором есть точка
        candidates = soup.find_all("div")
        text_block = max(
            candidates,
            key=lambda d: len(d.get_text(strip=True)) if "." in d.get_text() else 0,
            default=None,
        )

    if not text_block:
        return None

    question_text = text_block.get_text("\n", strip=True)

    # 2. Картинки внутри задания
    image_urls = []
    images_dir.mkdir(parents=True, exist_ok=True)
    for img in text_block.find_all("img"):
        src = img.get("src", "")
        if not src:
            continue
        full_url = urljoin(BANK_URL, src)
        # Скачиваем
        try:
            r = session.get(full_url, timeout=20)
            if r.status_code == 200 and r.content:
                # Имя файла: хэш URL + расширение
                ext = Path(urlparse(full_url).path).suffix or ".png"
                name = hashlib.md5(full_url.encode()).hexdigest()[:12] + ext
                (images_dir / name).write_bytes(r.content)
                image_urls.append(f"images/{name}")
        except requests.RequestException:
            pass

    # 3. Номер задания. На ФИПИ обычно есть поле «Линия №» или «Номер задания».
    task_num = None
    line_match = re.search(r"(?:Линия|Номер)\D{0,10}(\d{1,2})", soup.get_text())
    if line_match:
        task_num = int(line_match.group(1))
    else:
        # Запасной вариант: ищем класс с номером
        cls_block = soup.find(string=re.compile(r"^\s*\d{1,2}\s*$"))
        if cls_block:
            try:
                task_num = int(cls_block.strip())
            except ValueError:
                pass

    if not task_num or not (1 <= task_num <= 30):
        return None  # неопознанное задание

    return {
        "id": f"fipi_{subject[:3]}_{task_num}_{qid}",
        "task_num": task_num,
        "question": question_text,
        "answer": "",  # ФИПИ не публикует ответы в открытом банке
        "answer_aliases": [],
        "explanation": "",
        "best_answer": "",
        "image_urls": image_urls,
        "source": "fipi",
        "fipi_qid": qid,
    }


def crawl(subject: str, out_dir: Path, images_dir: Path,
          max_tasks: int | None = None, sleep: float = 1.0):
    proj = SUBJECT_CODES.get(subject)
    if not proj or proj.startswith("REPLACE"):
        print(f"❌ Нет кода ФИПИ для предмета '{subject}'.")
        print("   Открой oge.fipi.ru/bank в браузере, выбери предмет,")
        print("   скопируй параметр proj= из URL и пропиши его в SUBJECT_CODES.")
        sys.exit(1)

    out_dir.mkdir(parents=True, exist_ok=True)
    images_dir.mkdir(parents=True, exist_ok=True)

    s = make_session()

    # Соберём qid'ы со всех страниц списка
    print(f"[1/2] Список заданий по {subject}…")
    all_qids: list[str] = []
    page = 1
    while True:
        try:
            html = fetch_listing(s, proj, page=page)
        except requests.HTTPError as e:
            print(f"  HTTP {e.response.status_code} на странице {page}, стоп")
            break
        qids = parse_listing(html)
        new = [q for q in qids if q not in all_qids]
        if not new:
            print(f"  страница {page}: новых нет, конец")
            break
        all_qids.extend(new)
        print(f"  страница {page}: +{len(new)}, всего {len(all_qids)}")
        if max_tasks and len(all_qids) >= max_tasks:
            all_qids = all_qids[:max_tasks]
            break
        page += 1
        time.sleep(sleep)

    # Качаем каждое задание
    print(f"[2/2] Скачивание {len(all_qids)} заданий…")
    by_task: dict[int, list[dict]] = {}
    for i, qid in enumerate(all_qids, 1):
        try:
            html = fetch_task(s, proj, qid)
        except requests.HTTPError as e:
            print(f"  [{i}] {qid}: HTTP {e.response.status_code}")
            continue
        task = parse_task_html(html, qid, subject, images_dir, s)
        if task:
            by_task.setdefault(task["task_num"], []).append(task)
        if i % 25 == 0:
            print(f"  [{i}/{len(all_qids)}] обработано")
        time.sleep(sleep)

    # Сохраняем
    for num, tasks in sorted(by_task.items()):
        path = out_dir / f"{num:02d}.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(tasks, f, ensure_ascii=False, indent=2)
        print(f"  → {path}: {len(tasks)} заданий")

    print(f"\n⚠️ ВАЖНО: в этих JSON-файлах поле 'answer' пустое — ФИПИ ответы")
    print("    не публикует. Их нужно либо проставить вручную, либо")
    print("    обрабатывать через AI-проверку при выдаче пользователю.")


def main():
    parser = argparse.ArgumentParser(description="Парсер oge.fipi.ru/bank")
    parser.add_argument("--subject", required=True,
                        choices=list(SUBJECT_CODES.keys()),
                        help="предмет")
    parser.add_argument("--out", default=None,
                        help="папка для JSON (по умолчанию data/<subject>/tasks)")
    parser.add_argument("--images", default=None,
                        help="папка для картинок (по умолчанию data/<subject>/images)")
    parser.add_argument("--max-tasks", type=int, default=None,
                        help="скачать не больше N заданий (для теста)")
    parser.add_argument("--sleep", type=float, default=1.0,
                        help="пауза между запросами, сек")
    args = parser.parse_args()

    out = Path(args.out or f"data/{args.subject}/tasks")
    images = Path(args.images or f"data/{args.subject}/images")
    crawl(args.subject, out, images, max_tasks=args.max_tasks, sleep=args.sleep)


if __name__ == "__main__":
    main()
