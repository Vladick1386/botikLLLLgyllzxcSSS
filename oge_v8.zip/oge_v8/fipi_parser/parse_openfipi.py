"""
Парсер открытого банка заданий ОГЭ по ИНФОРМАТИКЕ.

Источник: https://openfipi.devinf.ru/tasks_oge/
Это зеркало ФИПИ, где задания уже расшифрованы из картинок в текст,
плюс есть пользовательские правильные ответы.

Запуск:
    pip install requests beautifulsoup4
    python fipi_parser/parse_openfipi.py --out data/informatics/tasks

Результат: JSON-файлы вида data/informatics/tasks/01.json, 02.json, …
"""

from __future__ import annotations
import argparse
import json
import os
import re
import sys
import time
from pathlib import Path

try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    print("ОШИБКА: нужно поставить зависимости.")
    print("Запусти: pip install requests beautifulsoup4")
    sys.exit(1)


BASE = "https://openfipi.devinf.ru"
LIST_URL = BASE + "/tasks_oge/page/{page}"
TASK_URL = BASE + "/task/{tid}"

USER_AGENT = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0 Safari/537.36"
)

session = requests.Session()
session.headers.update({"User-Agent": USER_AGENT})


def _get(url: str, retries: int = 3, sleep: float = 1.0) -> str:
    """GET с повторами и паузами."""
    for attempt in range(retries):
        try:
            r = session.get(url, timeout=20)
            if r.status_code == 200:
                return r.text
            print(f"  [HTTP {r.status_code}] {url}")
        except requests.RequestException as e:
            print(f"  [error attempt {attempt + 1}] {e}")
        time.sleep(sleep * (attempt + 1))
    raise RuntimeError(f"Не удалось скачать {url}")


def parse_listing_page(html: str) -> list[dict]:
    """Парсит страницу-список и возвращает [{id, task_num, has_answer, ...}, ...]."""
    soup = BeautifulSoup(html, "html.parser")
    rows = soup.select("table tr")
    out = []
    for tr in rows:
        cells = tr.find_all("td", recursive=False)
        if len(cells) < 4:
            continue
        # Первая ячейка — ссылка на задание
        link = cells[0].find("a")
        if not link or "/task/" not in link.get("href", ""):
            continue
        tid = link["href"].rsplit("/", 1)[-1]
        # 2-я колонка — номер задания на экзамене (id в кодификаторе)
        # Реально это код темы; номер задания тоже там, разберём позже
        try:
            cls_id = int(cells[1].get_text(strip=True))
        except ValueError:
            cls_id = None
        # 3-я: "True"/"False" — актуальное?
        actual = cells[2].get_text(strip=True).lower() == "true"
        # 4-я: есть ли ответ
        has_ans = cells[3].get_text(strip=True).lower() == "true"
        out.append({
            "tid": tid,
            "cls_id": cls_id,
            "actual": actual,
            "has_answer": has_ans,
        })
    return out


# Маппинг кодов классификатора (cls_id первые цифры) на номер задания ОГЭ.
# В openfipi cls_id — это что-то вроде 1152 = задание 11, тема 52.
# Но безопаснее тащить номер задания с самой страницы задания.
def parse_task_page(html: str, tid: str) -> dict | None:
    """Парсит одну страницу задания. Возвращает dict или None если не задание."""
    soup = BeautifulSoup(html, "html.parser")

    # На странице есть два маленьких заголовка h4 — там cls_id и task_num
    headers = soup.find_all(["h4"])
    task_num = None
    for h in headers:
        txt = h.get_text(strip=True)
        # task_num — это маленькое число (1..16)
        if txt.isdigit() and 1 <= int(txt) <= 20:
            task_num = int(txt)
            break

    # Текст задания — лежит в основном контенте, до раздела «Показать ответ»
    # Проще всего взять весь видимый текст и обрезать
    main = soup.find("main") or soup
    full = main.get_text("\n", strip=True)

    # Отрезаем всё после "Показать ответ"
    if "Показать ответ" in full:
        question_part, _, after = full.partition("Показать ответ")
    else:
        question_part, after = full, ""

    # В question_part есть ещё хвост с навигацией. Срежем по id задания.
    m = re.search(r"oge_[A-F0-9]+", question_part)
    if m:
        # Текст задания идёт после id
        question_part = question_part[m.end():].strip()

    question_text = question_part.strip()

    # Извлекаем ответ
    answer = ""
    if after:
        # после «Показать ответ» идёт код или ответ, потом «Показать решение»
        ans_part = after
        if "Показать решение" in ans_part:
            ans_part = ans_part.split("Показать решение")[0]
        # Дальше может быть «Ответ» — после которого идёт пустой блок (форма ввода)
        ans_part = ans_part.split("Ответ")[0]
        answer = ans_part.strip()

    if not task_num:
        return None

    return {
        "id": f"fipi_inf_{task_num}_{tid[-6:]}",
        "task_num": task_num,
        "question": question_text,
        "answer": answer,
        "answer_aliases": [],
        "explanation": "",
        "best_answer": "",
        "source": "openfipi",
        "fipi_id": tid,
    }


def crawl(out_dir: Path, max_pages: int | None = None,
          only_with_answer: bool = True, sleep: float = 0.5):
    """Главный цикл: проходит страницы списка, скачивает задания, сохраняет JSON-ы."""
    out_dir.mkdir(parents=True, exist_ok=True)

    # Накапливаем по номеру задания
    by_task: dict[int, list[dict]] = {}

    # 1. Соберём все tid'ы со списочных страниц
    print("[1/2] Сбор списка заданий…")
    all_listings: list[dict] = []
    page = 1
    while True:
        url = LIST_URL.format(page=page)
        print(f"  страница {page}: {url}")
        try:
            html = _get(url)
        except RuntimeError as e:
            print(f"  стоп: {e}")
            break
        items = parse_listing_page(html)
        if not items:
            print("  пусто, конец списка")
            break
        # фильтр актуальных + с ответами
        for it in items:
            if not it["actual"]:
                continue
            if only_with_answer and not it["has_answer"]:
                continue
            all_listings.append(it)
        page += 1
        if max_pages and page > max_pages:
            break
        time.sleep(sleep)

    print(f"  найдено {len(all_listings)} актуальных заданий с ответами")

    # 2. Скачаем каждое задание
    print("[2/2] Скачивание заданий…")
    for i, it in enumerate(all_listings, 1):
        url = TASK_URL.format(tid=it["tid"])
        try:
            html = _get(url)
        except RuntimeError as e:
            print(f"  [{i}/{len(all_listings)}] {it['tid']}: ошибка {e}")
            continue
        task = parse_task_page(html, it["tid"])
        if not task:
            continue
        if not task["question"] or len(task["question"]) < 20:
            # битый парсинг — пропускаем
            continue
        by_task.setdefault(task["task_num"], []).append(task)
        if i % 25 == 0:
            print(f"  [{i}/{len(all_listings)}] обработано")
        time.sleep(sleep)

    # 3. Сохраним
    for num, tasks in sorted(by_task.items()):
        path = out_dir / f"{num:02d}.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(tasks, f, ensure_ascii=False, indent=2)
        print(f"  → {path}: {len(tasks)} заданий")

    print(f"\nГотово. Всего заданий по {len(by_task)} номерам.")


def main():
    parser = argparse.ArgumentParser(description="Парсер открытого банка ОГЭ (информатика, openfipi.devinf.ru)")
    parser.add_argument("--out", default="data/informatics/tasks",
                        help="папка для JSON-файлов")
    parser.add_argument("--max-pages", type=int, default=None,
                        help="лимит страниц списка (по умолчанию — все)")
    parser.add_argument("--include-no-answer", action="store_true",
                        help="скачивать и задания без ответов (по умолчанию — только с ответами)")
    parser.add_argument("--sleep", type=float, default=0.5,
                        help="пауза между запросами, сек")
    args = parser.parse_args()

    crawl(Path(args.out), max_pages=args.max_pages,
          only_with_answer=not args.include_no_answer,
          sleep=args.sleep)


if __name__ == "__main__":
    main()
