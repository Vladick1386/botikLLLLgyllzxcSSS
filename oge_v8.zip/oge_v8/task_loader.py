"""
Загрузчик заданий из JSON-файлов.

Идея: задания хранятся в data/<subject>/tasks/<NN>.json,
где NN — номер задания на экзамене.

Бот при старте читает все эти файлы и складывает в память.
Если файла нет — задания берутся только из хардкод-словарей в subjects/<subject>.py.

Это нужно, чтобы:
1. Не редактировать .py при добавлении заданий
2. Парсер ФИПИ мог положить новые задания без изменения кода
3. Можно было быстро перезагрузить без перезапуска бота
"""

from __future__ import annotations
import json
import logging
import os
from pathlib import Path

log = logging.getLogger(__name__)


def load_tasks(data_dir: str | Path, subject: str) -> dict[int, list[dict]]:
    """Загружает все задания для предмета из data/<subject>/tasks/*.json.

    Возвращает словарь {task_num: [task1, task2, ...]}.
    Если папки нет — возвращает пустой словарь (тогда модуль использует
    свои хардкод-задания).
    """
    base = Path(data_dir) / subject / "tasks"
    if not base.exists():
        log.info("Папки %s нет — внешние задания не загружены", base)
        return {}

    out: dict[int, list[dict]] = {}
    for f in sorted(base.glob("*.json")):
        try:
            with open(f, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, json.JSONDecodeError) as e:
            log.warning("Не смог прочитать %s: %s", f, e)
            continue

        if not isinstance(data, list):
            log.warning("В %s ожидался список, получено %s", f, type(data).__name__)
            continue

        # Имя файла — номер задания (например, "01.json" → 1)
        try:
            num = int(f.stem.lstrip("0") or "0")
        except ValueError:
            log.warning("Имя файла %s не похоже на номер", f.name)
            continue

        valid = []
        for item in data:
            if not isinstance(item, dict):
                continue
            if "question" not in item:
                continue
            # Заполним недостающие поля по умолчанию
            item.setdefault("answer", "")
            item.setdefault("answer_aliases", [])
            item.setdefault("explanation", "")
            item.setdefault("best_answer", "")
            item.setdefault("id", f"{subject}_{num}_unknown")
            valid.append(item)

        if valid:
            out[num] = valid
            log.info("Загружено %d заданий №%d из %s", len(valid), num, f.name)

    return out


def merge_tasks(hardcoded: dict[int, list[dict]],
                from_files: dict[int, list[dict]]) -> dict[int, list[dict]]:
    """Объединяет хардкод-задания с заданиями из JSON.

    Хардкод-задания идут первыми (как «проверенные», у них точно есть ответы),
    задания из JSON добавляются после.
    Если ответ пустой ("") — задание помечается специальным флагом
    "no_auto_check" = True, чтобы бот не проверял его автоматически
    (а отдавал на проверку через AI).
    """
    merged: dict[int, list[dict]] = {}
    all_nums = set(hardcoded) | set(from_files)
    for num in all_nums:
        items = list(hardcoded.get(num, []))
        for it in from_files.get(num, []):
            if not it.get("answer"):
                it["no_auto_check"] = True
            items.append(it)
        merged[num] = items
    return merged
